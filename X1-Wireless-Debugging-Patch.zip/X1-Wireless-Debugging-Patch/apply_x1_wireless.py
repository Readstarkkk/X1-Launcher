#!/usr/bin/env python3
"""Apply X1 Wireless Debugging/System Monitor features to a local X1-Launcher checkout."""
from pathlib import Path
import re, sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
html_path = root / "app/src/main/assets/index.html"
kt_path = root / "app/src/main/java/com/x1launcher/app/MainActivity.kt"
gradle_path = root / "app/build.gradle"
for path in (html_path, kt_path, gradle_path):
    if not path.exists():
        raise SystemExit(f"Arquivo não encontrado: {path}. Execute na raiz do X1-Launcher.")
html, kt, gradle = (html_path.read_text(encoding="utf-8"),
                    kt_path.read_text(encoding="utf-8"),
                    gradle_path.read_text(encoding="utf-8"))
if "x1WirelessPage" in html or "fun pairWireless(" in kt:
    raise SystemExit("Parece que o patch X1 Wireless já foi aplicado; nada foi alterado.")

# The root settings.gradle already declares mavenCentral().
if "io.github.rhythmcache:adb-kt" not in gradle:
    if "dependencies {" in gradle:
        gradle = gradle.replace("dependencies {", "dependencies {\n    implementation 'io.github.rhythmcache:adb-kt:1.0.0'", 1)
    else:
        gradle += "\n\ndependencies {\n    implementation 'io.github.rhythmcache:adb-kt:1.0.0'\n}\n"
gradle, n = re.subn(r"minSdk\s+\d+", "minSdk 24", gradle, count=1)
if n != 1:
    raise SystemExit("Não encontrei minSdk no app/build.gradle; nenhum arquivo foi salvo.")

css = r"""
/* X1 System / Wireless Debugging */
.x1-bottom-nav{position:sticky;bottom:9px;z-index:16;display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:20px 0 12px;padding:7px;border:1px solid var(--line);border-radius:16px;background:rgba(12,8,20,.96);backdrop-filter:blur(12px)}
.x1-bottom-nav button{border:1px solid transparent;border-radius:11px;padding:12px 8px;background:transparent;color:var(--muted);font-weight:800}
.x1-bottom-nav button.active{background:#241333;border-color:#70409a;color:var(--bright)}
.x1-page{display:none}.x1-page.active{display:block}
.x1-device-hero,.x1-panel{border:1px solid var(--line);border-radius:17px;padding:15px;margin:11px 0;background:linear-gradient(145deg,#1b1129,#0b0812);box-shadow:var(--glow)}
.x1-device-hero h2,.x1-panel h3{font-size:16px;margin:0 0 7px}.x1-muted,.x1-help{font-size:11px;line-height:1.55;color:var(--muted)}
.x1-metrics{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.x1-metric{min-width:0;border:1px solid rgba(168,85,247,.28);border-radius:14px;padding:12px;background:rgba(18,12,29,.94)}
.x1-metric small{display:block;color:var(--muted);font-size:11px}.x1-metric strong{display:block;font-size:17px;margin-top:7px;overflow-wrap:anywhere}.x1-status{padding:11px 12px;border:1px solid rgba(168,85,247,.25);border-radius:12px;background:#0d0915;font-size:12px;line-height:1.45;margin:10px 0;overflow-wrap:anywhere}
.x1-fields{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin:12px 0}.x1-fields label{display:block;font-size:11px;color:var(--muted)}.x1-fields input{display:block;box-sizing:border-box;width:100%;margin-top:5px;padding:11px;border:1px solid #68438c;border-radius:10px;background:#100b1d;color:var(--text);min-width:0}
.x1-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}.x1-actions button{flex:1 1 145px}.x1-help{margin:9px 0 0}.x1-result{border-left:3px solid var(--purple);padding:10px 12px;margin-top:10px;background:rgba(10,7,17,.8);border-radius:0 9px 9px 0;font-size:11px;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere}
.x1-state-good{color:#a7f3d0}.x1-state-warn{color:#fcd34d}.x1-state-bad{color:#fca5a5}
@media(min-width:760px){.x1-metrics{grid-template-columns:repeat(4,minmax(0,1fr))}.x1-device-hero h2{font-size:20px}}
"""
if html.count("</style>") < 1 or html.count("<main>") != 1:
    raise SystemExit("Estrutura HTML inesperada; nenhum arquivo foi salvo.")
html = html.replace("</style>", css + "\n</style>", 1)
html = html.replace("<main>", '<main>\n<div id="x1AppsPage" class="x1-page active">', 1)
end_apps = '<div class="bottom-actions"><button class="primary-tile" id="openSettings"><span class="tile-icon">⚙</span>Configurações</button></div>'
if html.count(end_apps) != 1:
    raise SystemExit("Não encontrei o botão Configurações original no HTML; nenhum arquivo foi salvo.")
page2 = r"""
</div>
<section class="x1-page" id="x1WirelessPage" aria-label="X1 System">
  <div class="section-head"><div class="section-title"><span class="emoji">◈</span>X1 System</div><button class="link-button" id="x1RefreshDevice">Atualizar ↻</button></div>
  <div class="x1-device-hero"><h2 id="x1DeviceName">Identificando dispositivo…</h2><div class="x1-muted" id="x1DeviceDetails">Fabricante · modelo · versão do Android</div></div>
  <div class="x1-metrics">
    <div class="x1-metric"><small>RAM disponível</small><strong id="x1RamFree">—</strong><small id="x1RamTotal">Total: —</small></div>
    <div class="x1-metric"><small>Armazenamento livre</small><strong id="x1StorageFree">—</strong><small id="x1StorageTotal">Total: —</small></div>
    <div class="x1-metric"><small>Processador / SoC</small><strong id="x1CpuName">—</strong><small id="x1CpuDetails">ABI: —</small></div>
    <div class="x1-metric"><small>GPU / renderizador</small><strong id="x1GpuName">—</strong><small id="x1GpuVendor">Fabricante gráfico: —</small></div>
  </div>
  <div class="x1-panel"><h3>🌡 Temperatura</h3><div class="x1-status" id="x1Temperature">Consultando sensores disponíveis…</div><p class="x1-help">O X1 identifica um sensor CPU/SoC se o fabricante permitir leitura. Se não houver acesso, informa a temperatura da bateria separadamente; não inventa temperatura da CPU.</p></div>
  <div class="x1-panel">
    <h3>⌁ X1 Wireless Debugging</h3>
    <div class="x1-status" id="x1AdbState">Conexão: não verificada. Autorização: não verificada.</div>
    <p class="x1-help">No Android 11+, ative Depuração sem fio e abra “Parear dispositivo com código”. Use o IP, a porta e o código daquela tela. Depois use também a porta “Endereço IP e porta” da tela principal de Depuração sem fio — ela pode ser diferente da porta de pareamento. O telefone precisa estar na mesma rede Wi-Fi usada pelo X1.</p>
    <div class="x1-actions"><button class="secondary" id="x1OpenDevSettings">Opções do desenvolvedor</button><button class="secondary" id="x1OpenWirelessSettings">Depuração sem fio</button></div>
    <div class="x1-fields">
      <label>IP do próprio celular<input id="x1AdbHost" type="text" inputmode="decimal" placeholder="192.168.1.20" autocomplete="off"></label>
      <label>Porta de pareamento<input id="x1AdbPairPort" type="number" min="1" max="65535" placeholder="Porta da tela de pareamento"></label>
      <label>Código de pareamento<input id="x1AdbCode" type="password" inputmode="numeric" maxlength="6" placeholder="6 dígitos" autocomplete="off"></label>
      <label>Porta de depuração/conexão<input id="x1AdbConnectPort" type="number" min="1" max="65535" placeholder="Porta principal de depuração"></label>
    </div>
    <div class="x1-actions"><button class="primary" id="x1AdbPair">Parear</button><button class="primary" id="x1AdbConnect">Conectar e verificar</button></div>
    <div class="x1-actions"><button class="secondary" id="x1AdbCheck">Verificar conexão atual</button><button class="secondary" id="x1AdbDisconnect">Desconectar</button></div>
    <p class="x1-help">O código não é salvo. A chave ADB privada fica no armazenamento interno privado do X1. “Autorizado” só aparece depois de uma conexão TLS que passe no teste ADB.</p>
    <div id="x1AdbResult" class="x1-result">Nenhuma operação ADB executada nesta sessão.</div>
  </div>
  <div class="x1-panel">
    <h3>⚡ Ferramentas de otimização verificáveis</h3>
    <p class="x1-help">A primeira ferramenta ajusta as três escalas globais de animação do Android para 0,5×. O X1 guarda os valores originais e lê de volta cada ajuste. Não encerra apps, não altera limites térmicos e não promete aumento de FPS.</p>
    <div class="x1-actions"><button class="primary" id="x1ApplyOptimization">Aplicar otimização segura</button><button class="secondary" id="x1RestoreOptimization">Restaurar valores originais</button></div>
    <div id="x1OptimizationState" class="x1-result">Nenhuma otimização executada nesta sessão.</div>
  </div>
</section>
<div class="x1-bottom-nav" role="navigation" aria-label="Páginas do X1"><button id="x1TabApps" class="active">▦ Aplicativos</button><button id="x1TabSystem">◈ X1 System</button></div>
"""
html = html.replace(end_apps, end_apps + page2, 1)
js = r"""
/* X1 System frontend: displays native results; it never fakes successful pairing. */
(function(){
 const $=id=>document.getElementById(id);
 function fmt(n){if(!Number.isFinite(Number(n)))return '—';let v=Number(n),u=['B','KB','MB','GB','TB'],i=0;while(v>=1024&&i<u.length-1){v/=1024;i++}return (i?v.toFixed(1):Math.round(v))+' '+u[i]}
 function showPage(system){$('x1AppsPage').classList.toggle('active',!system);$('x1WirelessPage').classList.toggle('active',system);$('x1TabApps').classList.toggle('active',!system);$('x1TabSystem').classList.toggle('active',system);if(system)refreshSystem();window.scrollTo({top:0,behavior:'smooth'})}
 function result(id,text,ok=null){const n=$(id);n.textContent=text;n.classList.remove('x1-state-good','x1-state-warn','x1-state-bad');n.classList.add(ok===true?'x1-state-good':ok===false?'x1-state-bad':'x1-state-warn')}
 function refreshState(){try{const s=JSON.parse(window.X1.getWirelessState());$('x1AdbState').textContent='Pareamento: '+(s.paired?'concluído anteriormente':'não pareado')+' · Conexão: '+(s.connected?'ativa':'desconectada')+' · Autorização: '+(s.authorized?'confirmada por comando ADB':'não verificada')+(s.host?' · '+s.host+(s.port?':'+s.port:''):'')}catch(_){$('x1AdbState').textContent='Estado ADB disponível no APK recompilado.'}}
 function refreshSystem(){try{const d=JSON.parse(window.X1.getDeviceInfo());$('x1DeviceName').textContent=d.deviceName||'Dispositivo Android';$('x1DeviceDetails').textContent=[d.manufacturer,d.model,d.android].filter(Boolean).join(' · ');$('x1RamFree').textContent=fmt(d.ramAvailable);$('x1RamTotal').textContent='Total: '+fmt(d.ramTotal);$('x1StorageFree').textContent=fmt(d.storageAvailable);$('x1StorageTotal').textContent='Total: '+fmt(d.storageTotal);$('x1CpuName').textContent=d.soc||d.hardware||'Não identificado';$('x1CpuDetails').textContent='ABI: '+(d.abi||'—');$('x1GpuName').textContent=d.gpuRenderer||'Não disponível';$('x1GpuVendor').textContent='Fabricante gráfico: '+(d.gpuVendor||'—');$('x1Temperature').textContent=d.cpuTemperatureC!=null?'CPU/SoC: '+Number(d.cpuTemperatureC).toFixed(1)+' °C':d.batteryTemperatureC!=null?'CPU/SoC: indisponível · Bateria: '+Number(d.batteryTemperatureC).toFixed(1)+' °C':'Sensores de temperatura inacessíveis para este app.'}catch(_){$('x1DeviceName').textContent='Não foi possível consultar o aparelho. Recompile o APK com o patch.'}refreshState()}
 function fields(){return {host:$('x1AdbHost').value.trim(),pairPort:Number($('x1AdbPairPort').value),code:$('x1AdbCode').value.trim(),connectPort:Number($('x1AdbConnectPort').value)}}
 $('x1TabApps').addEventListener('click',()=>showPage(false));$('x1TabSystem').addEventListener('click',()=>showPage(true));$('x1RefreshDevice').addEventListener('click',refreshSystem);
 $('x1OpenDevSettings').addEventListener('click',()=>{if(!(window.X1&&window.X1.openDeveloperOptions&&window.X1.openDeveloperOptions()))toast('Não foi possível abrir as Opções do desenvolvedor.')});$('x1OpenWirelessSettings').addEventListener('click',()=>{if(!(window.X1&&window.X1.openWirelessDebuggingSettings&&window.X1.openWirelessDebuggingSettings()))toast('Abra manualmente Depuração sem fio nas Opções do desenvolvedor.')});
 $('x1AdbPair').addEventListener('click',()=>{const f=fields();if(!f.host||!f.pairPort||!/^[0-9]{6}$/.test(f.code)){result('x1AdbState','Informe IP, porta de pareamento e o código de 6 dígitos.',false);return}if(!window.X1||!window.X1.pairWireless){result('x1AdbState','Pareamento requer o APK recompilado com esta integração.',false);return}result('x1AdbState','Pareamento TLS/SPAKE2 em andamento…');window.X1.pairWireless(f.host,f.pairPort,f.code);$('x1AdbCode').value=''});
 $('x1AdbConnect').addEventListener('click',()=>{const f=fields();if(!f.host||!f.connectPort){result('x1AdbState','Informe o IP e a porta principal da tela Depuração sem fio.',false);return}if(!window.X1||!window.X1.connectWireless){result('x1AdbState','Conexão requer o APK recompilado.',false);return}result('x1AdbState','Estabelecendo TLS e verificando autorização…');window.X1.connectWireless(f.host,f.connectPort)});
 $('x1AdbCheck').addEventListener('click',()=>{if(window.X1&&window.X1.checkWirelessConnection){result('x1AdbState','Verificando sessão ADB…');window.X1.checkWirelessConnection()}else refreshState()});$('x1AdbDisconnect').addEventListener('click',()=>{if(window.X1&&window.X1.disconnectWireless)window.X1.disconnectWireless();else result('x1AdbState','Requer APK recompilado.',false)});
 $('x1ApplyOptimization').addEventListener('click',()=>{if(!confirm('Aplicar três escalas de animação do Android em 0,5×? Os valores originais serão guardados.'))return;if(window.X1&&window.X1.applyOptimization){result('x1OptimizationState','Aplicando e verificando os valores…');window.X1.applyOptimization()}else result('x1OptimizationState','Requer APK recompilado.',false)});$('x1RestoreOptimization').addEventListener('click',()=>{if(!confirm('Restaurar as escalas originais guardadas pelo X1?'))return;if(window.X1&&window.X1.restoreOptimization){result('x1OptimizationState','Restaurando e verificando…');window.X1.restoreOptimization()}else result('x1OptimizationState','Requer APK recompilado.',false)});
 window.onX1AdbResult=function(r){if(r.type==='pair'||r.type==='connect'||r.type==='check'||r.type==='disconnect'){result('x1AdbResult',r.message,r.ok);refreshState()}else if(r.type==='optimize'||r.type==='restore')result('x1OptimizationState',r.message,r.ok)};
 refreshState();
})();
"""
if "function initialize(){" not in html:
    raise SystemExit("Não encontrei initialize() no HTML; nenhum arquivo foi salvo.")
html = html.replace("function initialize(){", js + "\nfunction initialize(){", 1)

# Imports for official ADB client, sensor readings, and OpenGL renderer.
imports = [
    "import android.content.IntentFilter", "import android.os.BatteryManager",
    "import android.opengl.EGL14", "import android.opengl.EGLConfig",
    "import android.opengl.EGLDisplay", "import android.opengl.EGLContext",
    "import android.opengl.EGLSurface", "import android.opengl.GLES20",
    "import io.github.rhythmcache.adb.AdbClient", "import io.github.rhythmcache.adb.FileKeyProvider",
    "import kotlinx.coroutines.runBlocking", "import java.io.File"
]
for imp in imports:
    if imp not in kt:
        kt = kt.replace("package com.x1launcher.app\n", "package com.x1launcher.app\n\n" + imp + "\n", 1)
field_marker = "    private val imagePickerRequest = 4317\n"
if field_marker not in kt:
    raise SystemExit("Não encontrei imagePickerRequest no Kotlin; nenhum arquivo foi salvo.")
fields = """    @Volatile private var adbClient: AdbClient? = null
    @Volatile private var adbHost: String? = null
    @Volatile private var adbConnectPort: Int = 0
    @Volatile private var adbConnected = false
    @Volatile private var adbAuthorized = false
    private val adbPrefs by lazy { getSharedPreferences(\"x1_wireless_debugging\", MODE_PRIVATE) }
    private val optimizationPrefs by lazy { getSharedPreferences(\"x1_optimization_backup\", MODE_PRIVATE) }
"""
kt = kt.replace(field_marker, field_marker + fields, 1)

helpers = r'''    private fun adbKeyProvider(): FileKeyProvider = FileKeyProvider(File(filesDir, "x1-adbkey"))

    private fun validIpv4(host: String): Boolean {
        val parts = host.split('.')
        return parts.size == 4 && parts.all { part ->
            val number = part.toIntOrNull()
            number != null && number in 0..255 && part.isNotBlank()
        }
    }

    private fun sendAdbEvent(type: String, ok: Boolean, message: String) {
        val payload = JSONObject().put("type", type).put("ok", ok).put("message", message)
        runOnUiThread {
            if (::webView.isInitialized) {
                val js = "window.onX1AdbResult && window.onX1AdbResult(JSON.parse(${JSONObject.quote(payload.toString())}));"
                webView.evaluateJavascript(js, null)
            }
        }
    }

    private fun newAdbThread(name: String, block: () -> Unit) {
        Thread({
            try { block() }
            catch (e: Exception) {
                adbConnected = adbClient != null
                adbAuthorized = false
                sendAdbEvent(name, false, "Falha: ${e.message?.take(220) ?: "operação ADB não concluída"}")
            }
        }, "X1-$name").start()
    }

    private fun closeAdbClient() {
        val old = adbClient
        adbClient = null
        adbConnected = false
        adbAuthorized = false
        runCatching { old?.close() }
    }

    private fun ensureAdbClient(): AdbClient {
        val current = adbClient ?: throw IllegalStateException("Conecte ao endpoint de depuração antes de executar esta ferramenta.")
        val test = runBlocking { current.shell("echo X1_ADB_SESSION_OK") }
        if (!test.isSuccess || !test.stdoutText.contains("X1_ADB_SESSION_OK")) {
            closeAdbClient()
            throw IllegalStateException("A sessão ADB perdeu a conexão ou a autorização. Conecte novamente.")
        }
        adbConnected = true
        adbAuthorized = true
        return current
    }

    private fun wirelessStateJson(): String = JSONObject()
        .put("paired", adbPrefs.getBoolean("paired", false))
        .put("connected", adbConnected && adbClient != null)
        .put("authorized", adbAuthorized && adbConnected && adbClient != null)
        .put("host", adbHost ?: adbPrefs.getString("host", ""))
        .put("port", if (adbConnectPort > 0) adbConnectPort else adbPrefs.getInt("connectPort", 0))
        .put("message", adbPrefs.getString("lastMessage", "Ainda não conectado"))
        .toString()

    private fun pairWirelessAsync(host: String, pairingPort: Int, code: String) {
        newAdbThread("pair") {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) throw IllegalStateException("Depuração sem fio exige Android 11 ou superior.")
            if (!validIpv4(host)) throw IllegalArgumentException("IP inválido. Use o IPv4 mostrado pelo Android.")
            if (pairingPort !in 1..65535) throw IllegalArgumentException("Porta de pareamento inválida.")
            if (!code.matches(Regex("^[0-9]{6}$"))) throw IllegalArgumentException("O código deve ter 6 dígitos.")
            val result = runBlocking { AdbClient.pairTls(host = host, port = pairingPort, pairingCode = code, keyProvider = adbKeyProvider()) }
            if (!result.isSuccess) throw IllegalStateException("Pareamento TLS/SPAKE2 recusado. Confira IP, porta e código temporário.")
            adbPrefs.edit().putBoolean("paired", true).putString("host", host).putInt("pairPort", pairingPort)
                .putString("lastMessage", "Pareamento concluído; conexão ainda precisa ser testada").apply()
            sendAdbEvent("pair", true, "Pareamento TLS/SPAKE2 concluído. Informe a porta principal e toque em Conectar e verificar.")
        }
    }

    private fun connectWirelessAsync(host: String, port: Int, eventType: String = "connect") {
        newAdbThread(eventType) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) throw IllegalStateException("Depuração sem fio TLS exige Android 11 ou superior.")
            if (!validIpv4(host)) throw IllegalArgumentException("IP inválido. Use o IPv4 mostrado pelo Android.")
            if (port !in 1..65535) throw IllegalArgumentException("Porta de conexão inválida.")
            closeAdbClient()
            val client = runBlocking { AdbClient.connectTls(host = host, port = port, keyProvider = adbKeyProvider()) }
            try {
                val test = runBlocking { client.shell("echo X1_ADB_AUTHORIZED") }
                if (!test.isSuccess || !test.stdoutText.contains("X1_ADB_AUTHORIZED")) throw IllegalStateException("Conexão aberta, mas o teste ADB não confirmou autorização.")
                adbClient = client
                adbHost = host
                adbConnectPort = port
                adbConnected = true
                adbAuthorized = true
                adbPrefs.edit().putString("host", host).putInt("connectPort", port)
                    .putString("lastMessage", "Conexão TLS validada e comando de teste confirmado").apply()
                sendAdbEvent(eventType, true, "Conectado por TLS. Comando ADB respondeu; autorização verificada.")
            } catch (e: Exception) {
                runCatching { client.close() }
                throw e
            }
        }
    }

    private fun checkWirelessAsync() {
        newAdbThread("check") {
            val client = ensureAdbClient()
            val test = runBlocking { client.shell("getprop ro.product.model") }
            if (!test.isSuccess) throw IllegalStateException("O dispositivo não respondeu ao comando de verificação.")
            val model = test.stdoutText.trim().take(100).ifBlank { "resposta vazia" }
            adbPrefs.edit().putString("lastMessage", "Conexão verificada; modelo: $model").apply()
            sendAdbEvent("check", true, "Conexão ADB ativa e autorizada. getprop respondeu: $model")
        }
    }

    private fun applyOptimizationAsync(restore: Boolean) {
        val event = if (restore) "restore" else "optimize"
        newAdbThread(event) {
            val client = ensureAdbClient()
            val keys = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
            val prefs = optimizationPrefs
            if (!restore && !prefs.getBoolean("backup_saved", false)) {
                val originals = linkedMapOf<String, String>()
                keys.forEach { key ->
                    val read = runBlocking { client.shell("settings get global $key") }
                    if (!read.isSuccess) throw IllegalStateException("Não foi possível ler o valor original de $key.")
                    originals[key] = read.stdoutText.trim()
                }
                val editor = prefs.edit().putBoolean("backup_saved", true)
                originals.forEach { (key, value) -> editor.putString("before_$key", value) }
                editor.apply()
            }
            if (restore && !prefs.getBoolean("backup_saved", false)) throw IllegalStateException("Nenhum backup foi salvo; não há valores para restaurar.")
            val lines = mutableListOf<String>()
            var passedCount = 0
            keys.forEach { key ->
                val original = prefs.getString("before_$key", "null") ?: "null"
                val command = if (restore && (original.isBlank() || original == "null")) "settings delete global $key"
                    else "settings put global $key ${if (restore) original else "0.5"}"
                val write = runBlocking { client.shell(command) }
                val verify = runBlocking { client.shell("settings get global $key") }
                val actual = verify.stdoutText.trim()
                val expected = if (restore) original else "0.5"
                val match = if (expected.isBlank() || expected == "null") actual == "null" else {
                    val e = expected.toFloatOrNull(); val a = actual.toFloatOrNull()
                    e != null && a != null && kotlin.math.abs(e - a) < 0.001f
                }
                val success = write.isSuccess && verify.isSuccess && match
                if (success) passedCount++
                lines += "$key: esperado ${if (restore) original else "0.5"}, leitura $actual — ${if (success) "OK" else "FALHOU"}"
            }
            if (restore && passedCount == keys.size) prefs.edit().remove("backup_saved").apply()
            val allOk = passedCount == keys.size
            val message = (if (restore) "Restauração" else "Otimização") + ": $passedCount/${keys.size} ajustes verificados.\n" + lines.joinToString("\n") +
                if (allOk) "\nResultado confirmado por leitura de retorno." else "\nAlguns ajustes falharam; veja os resultados e tente restaurar os valores guardados."
            prefs.edit().putString("last_result", message).apply()
            sendAdbEvent(event, allOk, message)
        }
    }

    private fun deviceInfoJson(): String {
        return try {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mem = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mem)
            val fs = StatFs(Environment.getDataDirectory().absolutePath)
            val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && Build.SOC_MODEL.isNotBlank())
                listOf(Build.SOC_MANUFACTURER, Build.SOC_MODEL).filter { it.isNotBlank() }.joinToString(" ")
            else Build.HARDWARE.ifBlank { "Não identificado" }
            val gpu = readGpuRenderer()
            val cpuTemp = readCpuTemperature()
            val batteryTemp = try {
                registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    ?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
                    ?.takeIf { it != Int.MIN_VALUE && it > 0 }?.div(10.0)
            } catch (_: Exception) { null }
            JSONObject().put("ok", true)
                .put("deviceName", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
                .put("manufacturer", Build.MANUFACTURER).put("model", Build.MODEL)
                .put("android", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                .put("soc", soc).put("hardware", Build.HARDWARE)
                .put("abi", Build.SUPPORTED_ABIS.firstOrNull() ?: "Não identificado")
                .put("gpuRenderer", gpu?.first ?: JSONObject.NULL).put("gpuVendor", gpu?.second ?: JSONObject.NULL)
                .put("cpuTemperatureC", cpuTemp ?: JSONObject.NULL).put("batteryTemperatureC", batteryTemp ?: JSONObject.NULL)
                .put("ramTotal", mem.totalMem).put("ramAvailable", mem.availMem)
                .put("storageTotal", fs.totalBytes).put("storageAvailable", fs.availableBytes).toString()
        } catch (_: Exception) { JSONObject().put("ok", false).put("error", "device_info_unavailable").toString() }
    }

    private fun readCpuTemperature(): Double? {
        return try {
            val zones = File("/sys/class/thermal").listFiles()?.filter { it.name.startsWith("thermal_zone") }.orEmpty()
            val candidates = zones.mapNotNull { zone ->
                val type = runCatching { File(zone, "type").readText().trim().lowercase() }.getOrDefault("")
                if (!(type.contains("cpu") || type.contains("soc") || type.contains("ap") || type.contains("cluster") || type.contains("tsens"))) return@mapNotNull null
                val raw = runCatching { File(zone, "temp").readText().trim().toDouble() }.getOrNull() ?: return@mapNotNull null
                val c = if (raw > 1000.0 || raw < -1000.0) raw / 1000.0 else raw
                if (c in 0.0..125.0) (if (type.contains("cpu") || type.contains("soc") || type.contains("ap")) 0 else 1) to c else null
            }
            candidates.minByOrNull { it.first }?.second
        } catch (_: Exception) { null }
    }

    private fun readGpuRenderer(): Pair<String, String>? {
        val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (display == EGL14.EGL_NO_DISPLAY) return null
        var trackedSurface: EGLSurface? = null
        var trackedContext: EGLContext? = null
        try {
            val version = IntArray(2)
            if (!EGL14.eglInitialize(display, version, 0, version, 1)) return null
            val attrs = intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE)
            val configs = arrayOfNulls<EGLConfig>(1)
            val count = IntArray(1)
            if (!EGL14.eglChooseConfig(display, attrs, 0, configs, 0, 1, count, 0) || count[0] == 0) return null
            val config = configs[0] ?: return null
            val context = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
            trackedContext = context
            val surface = EGL14.eglCreatePbufferSurface(display, config, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
            trackedSurface = surface
            if (context == EGL14.EGL_NO_CONTEXT || surface == EGL14.EGL_NO_SURFACE) return null
            if (!EGL14.eglMakeCurrent(display, surface, surface, context)) return null
            val renderer = GLES20.glGetString(GLES20.GL_RENDERER)?.trim().orEmpty()
            val vendor = GLES20.glGetString(GLES20.GL_VENDOR)?.trim().orEmpty()
            return if (renderer.isBlank()) null else renderer to vendor
        } catch (_: Exception) { return null }
        finally {
            try {
                EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                trackedSurface?.let { if (it != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, it) }
                trackedContext?.let { if (it != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, it) }
                EGL14.eglTerminate(display)
            } catch (_: Exception) { }
        }
    }

'''
if kt.count("    private inner class X1Bridge {") != 1:
    raise SystemExit("Não encontrei X1Bridge no Kotlin; nenhum arquivo foi salvo.")
kt = kt.replace("    private inner class X1Bridge {", helpers + "    private inner class X1Bridge {", 1)
bridge_marker = "        @JavascriptInterface\n        fun getDeviceStats(): String = deviceStatsJson()\n"
bridge_methods = r'''        @JavascriptInterface
        fun getDeviceInfo(): String = deviceInfoJson()

        @JavascriptInterface
        fun getWirelessState(): String = wirelessStateJson()

        @JavascriptInterface
        fun openDeveloperOptions(): Boolean = try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
        } catch (_: Exception) { false }

        @JavascriptInterface
        fun openWirelessDebuggingSettings(): Boolean = openDeveloperOptions()

        @JavascriptInterface
        fun pairWireless(host: String, pairingPort: Int, code: String) = pairWirelessAsync(host, pairingPort, code)

        @JavascriptInterface
        fun connectWireless(host: String, port: Int) = connectWirelessAsync(host, port)

        @JavascriptInterface
        fun checkWirelessConnection() = checkWirelessAsync()

        @JavascriptInterface
        fun disconnectWireless() {
            closeAdbClient()
            adbPrefs.edit().putString("lastMessage", "Desconectado pelo usuário").apply()
            sendAdbEvent("disconnect", true, "Sessão ADB fechada pelo usuário. O pareamento remoto não foi revogado.")
        }

        @JavascriptInterface
        fun applyOptimization() = applyOptimizationAsync(false)

        @JavascriptInterface
        fun restoreOptimization() = applyOptimizationAsync(true)

'''
if kt.count(bridge_marker) != 1:
    raise SystemExit("Não encontrei getDeviceStats() no Kotlin; nenhum arquivo foi salvo.")
kt = kt.replace(bridge_marker, bridge_methods + bridge_marker, 1)
destroy_marker = "    override fun onDestroy() {\n        fileChooserCallback?.onReceiveValue(null)"
if kt.count(destroy_marker) != 1:
    raise SystemExit("Não encontrei onDestroy() no Kotlin; nenhum arquivo foi salvo.")
kt = kt.replace(destroy_marker, "    override fun onDestroy() {\n        closeAdbClient()\n        fileChooserCallback?.onReceiveValue(null)", 1)

# Write only after all transformations succeed.
html_path.write_text(html, encoding="utf-8")
kt_path.write_text(kt, encoding="utf-8")
gradle_path.write_text(gradle, encoding="utf-8")
print("X1 Wireless Debugging aplicado a HTML, Kotlin e Gradle.")
print("Compile e teste o APK antes de instalar. Pareamento requer Android 11+ e portas atuais exibidas pelo Android.")
