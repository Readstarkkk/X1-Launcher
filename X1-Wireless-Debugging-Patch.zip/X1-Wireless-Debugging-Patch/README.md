# X1 Wireless Debugging — patch executável

Este patch modifica o projeto X1 Launcher existente sem substituir a página atual de aplicativos e sem remover as configurações avançadas já presentes.

## Aplicar no Termux/Ubuntu

1. Faça um backup ou commit dos arquivos atuais.
2. Extraia `X1-Wireless-Debugging-Patch.zip`.
3. Entre na raiz do clone `X1-Launcher` (onde está `settings.gradle`).
4. Execute:

```bash
python3 /caminho/para/apply_x1_wireless.py .
```

## O que altera

- `app/src/main/assets/index.html`: segunda página **X1 System**, campos de pareamento/conexão e resultados de otimização.
- `app/src/main/java/com/x1launcher/app/MainActivity.kt`: leitura do dispositivo, pareamento TLS/SPAKE2 real, sessão ADB, status e otimização verificável.
- `app/build.gradle`: dependência `io.github.rhythmcache:adb-kt:1.0.0` e `minSdk 24`.

O repositório já usa `mavenCentral()` em `settings.gradle`.

## Compilar

```bash
gradle assembleDebug
```

Ou faça commit/push no seu GitHub e execute o workflow Android do projeto.

## Como usar

1. Abra **X1 System** na barra inferior.
2. RAM e armazenamento vêm das APIs Android. CPU/SoC usa informações expostas pelo sistema. GPU é lida pelo renderizador OpenGL quando disponível. A temperatura CPU/SoC depende de sensores legíveis; se indisponível, a temperatura da bateria aparece rotulada separadamente.
3. No Android 11+, ative **Depuração sem fio**. Em **Parear dispositivo com código**, use IP/porta/código nos campos de pareamento. Depois informe a porta principal mostrada como **Endereço IP e porta** e toque em **Conectar e verificar**. As duas portas podem ser diferentes.
4. “Autorizado” só aparece depois que a conexão TLS funciona e um comando de teste ADB retorna com sucesso.
5. A otimização inicial define três escalas globais de animação para 0,5×. O X1 salva os valores originais e verifica os valores de volta; há botão para restaurar. Não encerra apps, não muda limites térmicos e não promete aumento de FPS.

## Segurança e limites

O código temporário não é salvo. A chave ADB privada fica no armazenamento interno privado do X1. “Desconectar” fecha a sessão do X1, mas não remove a autorização do host no Android; para revogar, use a tela de Depuração sem fio do sistema.

Este pacote é um patcher, não um APK já compilado. O repositório não foi atualizado diretamente nesta sessão, pois o conector não autorizou gravação no GitHub. Compile e teste no aparelho antes de usar.
